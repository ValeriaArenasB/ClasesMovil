package com.example.application1

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.application1.databinding.ActivityPantalla2Binding

class Pantalla2 : AppCompatActivity() {
    lateinit var binding: ActivityPantalla2Binding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPantalla2Binding.inflate(layoutInflater)



        setContentView(binding.root)

        //el mensaje recibido se recibe en la variable global "intent"
        //var mensaje = intent.getStringExtra("carta")

        //Desempaquetar el Bundle
        var paquete = intent.getBundleExtra("paquete")

        binding.textView.text = paquete?.getString("Nombre")
                                // paquete!! si estoy seguro de que no llegara nada null
        binding.textView2.text = paquete?.getInt("Edad").toString()
        binding.textView3.text = paquete?.getFloat("Estatura").toString()


    }
}
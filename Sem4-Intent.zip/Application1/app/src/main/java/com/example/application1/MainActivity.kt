package com.example.application1

import android.content.Intent
import android.os.Bundle
import android.util.Log
//import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.application1.databinding.ActivityMainBinding
import android.widget.Toast

//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //manejo de binding:
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)





        binding.Boton1.setOnClickListener {
            Toast.makeText(baseContext, "Hola, " + binding.NombreTxt.text, Toast.LENGTH_LONG).show()

            //Intent(donde estoy, hacia donde voy)
            val i = Intent(this, Pantalla2::class.java)

            // startActivity(Intent(this,Pantalla2::class.java)) MEJOR

           //  i.putExtra("carta", "hola amor")

            val caja = Bundle()
            caja.putString("Nombre", binding.NombreTxt.text.toString())
            caja.putInt("Edad", binding.EdadTxt.text.toString().toInt())
            caja.putFloat("Estatura", binding.PesoTxt.text.toString().toFloat())
            i.putExtra("paquete", caja)




            startActivity(i)

        }

        //baseContext es el contexto de TODA LA APP
        //applicationContext es el contexto de ESTA PANTALLA
        Toast.makeText(baseContext, mostrarMensaje("HOLAA").toString(), Toast.LENGTH_SHORT) //.show() aca retorna 1 (del metodo donde viene)

        // Log.i("PrimeraPantalla",mostrarMensaje("HOLAA").toString() ) //informacion
        // Log.d("PrimeraPantalla",mostrarMensaje("HOLAA").toString() ) //debug
        // Log.e("PrimeraPantalla",mostrarMensaje("HOLAA").toString() ) //error
        // Log.w("PrimeraPantalla",mostrarMensaje("HOLAA").toString() ) //warning


    }

    private fun mostrarMensaje (text:String): Int{
        var msj = Toast.makeText(baseContext, "HOLAAA", Toast.LENGTH_LONG)
        msj.show()
        return 1

    }
}
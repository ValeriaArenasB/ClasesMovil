package com.example.application1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.application1.databinding.ActivityPantalla2Binding

class Pantalla2 : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    lateinit var binding: ActivityPantalla2Binding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPantalla2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.spinner.onItemSelectedListener = this


        var paquete = intent.getBundleExtra("paquete")

        // Asegurar que el nombre no sea null
        binding.textView.text = paquete?.getString("Nombre") ?: "Nombre no recibido"


        binding.button2.setOnClickListener {
            startActivity(Intent(this, PantallaWeb::class.java))
        }

        binding.button1.setOnClickListener {
            val seleccion = binding.spinner.selectedItem.toString()
            val i = Intent(this, PantallaFrame::class.java)

            val caja = Bundle()
            caja.putString("Nombre", paquete?.getString("Nombre"))
            caja.putString("Profesion", seleccion)

            i.putExtra("paquete", caja)
            startActivity(i)
        }

    }


    override fun onItemSelected(parent: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        //parent: el objeto que esta llamado el objeto = el spinner

        Toast.makeText(baseContext, "Selección: " + parent?.selectedItemId + ", " + parent?.selectedItem,
            Toast.LENGTH_SHORT)
            .show()
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}
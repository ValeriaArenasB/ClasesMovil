package com.example.application1

import java.io.IOException
import java.io.InputStream


class Miscellaneous {



}
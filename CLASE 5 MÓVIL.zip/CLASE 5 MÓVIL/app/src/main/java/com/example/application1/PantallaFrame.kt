package com.example.application1

import android.os.Bundle
import android.webkit.WebViewClient
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.application1.databinding.ActivityPantallaFrameBinding
import com.example.application1.databinding.ActivityPantallaWebBinding

class PantallaFrame : AppCompatActivity() {

    lateinit var binding: ActivityPantallaFrameBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //inicializar el binding
        binding = ActivityPantallaFrameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val paquete = intent.getBundleExtra("paquete")

        val nombre = paquete?.getString("Nombre") ?: "No recibido"
        val profesion = paquete?.getString("Profesion") ?: "No seleccionado"

        binding.textView3.text = ("$nombre\n, $profesion")




    }
}
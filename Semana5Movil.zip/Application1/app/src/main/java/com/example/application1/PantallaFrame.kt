package com.example.application1

import android.os.Bundle
import android.webkit.WebViewClient
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.application1.databinding.ActivityPantallaFrameBinding
import com.example.application1.databinding.ActivityPantallaWebBinding

class PantallaFrame : AppCompatActivity() {

    lateinit var binding: ActivityPantallaFrameBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        //inicializar el binding
        binding = ActivityPantallaFrameBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val respuesta1 = intent.getBundleExtra("paquete1")
        val respuesta2 = intent.getBundleExtra("paquete2")
        //aqui si puedo usar el !! porque por default viene seleccionado Español, entonces siempre llegará algo
        binding.textView3.text = (respuesta1.toString() + respuesta2.toString() )




    }
}
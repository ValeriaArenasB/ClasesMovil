package com.example.app_2510

import android.os.Bundle
//import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.app_2510.databinding.ActivityMainBinding

//import androidx.core.view.ViewCompat
//import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //arrancar acfuhbeiufhieha
        binding = MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)



        }
    }
}